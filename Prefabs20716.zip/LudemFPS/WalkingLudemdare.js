﻿//Movement.js, based on RigidbodyFPSWalker

var speed : float;
var jumpHeight : float;
var maxVelocityChange : float;
var grounded : boolean;
var cam : Transform;
function Start () {

}

function FixedUpdate () {
	if (grounded) {
		var targetVelocity = Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
		targetVelocity = cam.transform.TransformDirection(targetVelocity);
		targetVelocity *= speed;
		var v = GetComponent.<Rigidbody>().velocity;
		var velocityChange = (targetVelocity-v);
		velocityChange.x = Mathf.Clamp(velocityChange.x, -maxVelocityChange, maxVelocityChange);
		velocityChange.z = Mathf.Clamp(velocityChange.z, -maxVelocityChange, maxVelocityChange);
		velocityChange.y = 0;
	
		GetComponent.<Rigidbody>().AddForce(velocityChange, ForceMode.VelocityChange);
	}
	if(Input.GetButtonDown("Jump") && grounded){
		GetComponent.<Rigidbody>().AddForce(transform.up*jumpHeight);
		}
	grounded=false;
}

function OnCollisionStay(collision : Collision) {
	if (collision.transform.tag != "Not Ground"){
		grounded=true;
	}
}